// Al cargar la página, mostrar mensaje de bienvenida
window.addEventListener('load', () => {
  const modal = document.getElementById('modal-bienvenida');
  modal.style.display = 'flex';
});

// Cerrar modal al hacer clic en la X
document.querySelector('.close').addEventListener('click', () => {
  document.getElementById('modal-bienvenida').style.display = 'none';
});

// Validación de formulario de contacto
document.getElementById('formulario-contacto').addEventListener('submit', function (e) {
  e.preventDefault(); // Evita recargar la página

  const nombre = document.getElementById('nombre');
  const email = document.getElementById('email');
  const mensaje = document.getElementById('mensaje');

  let valido = true;

  // Verificar que todos los campos estén llenos
  [nombre, email, mensaje].forEach(input => {
    if (!input.value.trim()) {
      input.style.borderColor = 'red';
      valido = false;
    } else {
      input.style.borderColor = '#ccc';
    }
  });

  // Validar email
  const emailValido = /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(email.value);
  if (!emailValido) {
    email.style.borderColor = 'red';
    valido = false;
    alert('Por favor, introduce un correo electrónico válido.');
    return;
  }

  // Mostrar mensaje si todo está bien
  if (valido) {
    alert(`Gracias por tu mensaje, César Edú Palomino Berrocal de la UTP. ¡Te responderé pronto!`);
    this.reset(); // Limpiar formulario
    [nombre, email, mensaje].forEach(input => input.style.borderColor = '#ccc');
  } else {
    alert('Por favor, completa todos los campos correctamente.');
  }
});

// Menú hamburguesa para móviles
const hamburger = document.querySelector('.hamburger');
const navLinks = document.querySelector('.nav-links');

hamburger.addEventListener('click', () => {
  navLinks.classList.toggle('open');
});

// Cierre del modal si haces clic fuera del contenido
window.addEventListener('click', (e) => {
  const modal = document.getElementById('modal-bienvenida');
  if (e.target === modal) {
    modal.style.display = 'none';
  }
});
